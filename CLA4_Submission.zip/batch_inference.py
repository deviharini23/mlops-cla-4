import pandas as pd
import joblib
from sklearn.model_selection import train_test_split

# Load dataset and trained model
df = pd.read_csv("train.csv")
model = joblib.load("model.pkl")

# Select the same features used during training
features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]
X = df[features]
y = df["Survived"]

# Recreate the same test split
_, X_test, _, _ = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Select 20 passenger records
batch_data = X_test.iloc[1:21].copy()

# Predict all 20 passengers
batch_data["Predicted_Survived"] = model.predict(
    X_test.iloc[1:21]
).astype(int)

# Save results
batch_data.to_csv("batch_predictions.csv", index=False)

print("Batch inference completed!")
print("Number of predictions:", len(batch_data))
print(batch_data)
print("Results saved to batch_predictions.csv")
