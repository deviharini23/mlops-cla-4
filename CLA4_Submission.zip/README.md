
# ML Model Deployment Strategies and Model Serving using FastAPI

## Project Overview
This project trains a machine learning model to predict Titanic passenger survival and demonstrates online, batch, streaming, and API-based inference.

## Dataset
Kaggle Titanic Dataset: https://www.kaggle.com/competitions/titanic/data

## Machine Learning Model
- Algorithm: Random Forest Classifier
- Preprocessing: Missing-value imputation and categorical encoding
- Evaluation: Accuracy on the test dataset
- Model file: model.pkl

## Tasks Completed
1. Model training and evaluation.
2. Online inference for one passenger.
3. Batch inference for 20 passengers.
4. Streaming inference for 10 passengers with a one-second delay.
5. FastAPI deployment with health and prediction endpoints.
6. Input validation and API testing.

## API Endpoints
- GET /health — checks API health.
- POST /predict — predicts passenger survival.
- GET /docs — interactive Swagger documentation.

## Project Files
- model.pkl — trained ML pipeline.
- batch_predictions.csv — batch prediction results.
- app.py — FastAPI application.
- client.py — Python API client.
- requirements.txt — required Python packages.
- README.md — project documentation.

## Installation
Install dependencies using:

pip install -r requirements.txt

## Running the API
Run the following command from the project directory:

uvicorn app:app --reload

Open http://127.0.0.1:8000/docs to test the API.

## Conclusion
The project demonstrates how a trained machine learning model can be reused for online, batch, streaming, and API-based predictions.
