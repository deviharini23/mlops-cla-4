import pandas as pd
import joblib

# Load the trained model
model = joblib.load("model.pkl")

# One unseen passenger record
passenger = pd.DataFrame([{
    "Pclass": 3,
    "Sex": "male",
    "Age": 22,
    "SibSp": 1,
    "Parch": 0,
    "Fare": 7.25,
    "Embarked": "S"
}])

# Make the prediction
prediction = int(model.predict(passenger)[0])

print("Passenger details:")
print(passenger)
print("Predicted Survived:", prediction)
print(
    "Prediction:",
    "Survived" if prediction == 1 else "Did Not Survive"
)
