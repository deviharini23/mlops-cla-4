import pandas as pd
import joblib
import time
from sklearn.model_selection import train_test_split

# Load dataset and trained model
df = pd.read_csv("train.csv")
model = joblib.load("model.pkl")

features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]
X = df[features]
y = df["Survived"]

# Recreate the original test split
_, X_test, _, _ = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Select 10 records for streaming
stream_data = X_test.iloc[21:31].copy()

print("Starting streaming inference...")

for index, (_, passenger) in enumerate(stream_data.iterrows(), start=1):
    prediction = int(model.predict(pd.DataFrame([passenger]))[0])

    print(
        f"Record {index}: Predicted Survived = {prediction} "
        f"({'Survived' if prediction == 1 else 'Did Not Survive'})"
    )

    if index < len(stream_data):
        time.sleep(1)

print("Streaming inference completed!")
