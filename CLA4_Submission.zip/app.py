
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Literal
import pandas as pd
import joblib

# Load the previously trained model
model = joblib.load("model.pkl")

app = FastAPI(
    title="Titanic Survival Prediction API",
    description="Predict passenger survival using a trained ML pipeline",
    version="1.0"
)

# Validate incoming passenger details
class Passenger(BaseModel):
    Pclass: int = Field(ge=1, le=3)
    Sex: Literal["male", "female"]
    Age: float = Field(ge=0, le=100)
    SibSp: int = Field(ge=0, le=10)
    Parch: int = Field(ge=0, le=10)
    Fare: float = Field(ge=0)
    Embarked: Literal["S", "C", "Q"]

# Health-check endpoint
@app.get("/health")
def health():
    return {"status": "healthy", "model_loaded": True}

# Prediction endpoint
@app.post("/predict")
def predict(passenger: Passenger):
    passenger_data = pd.DataFrame(
        [passenger.model_dump()]
    )

    prediction = int(model.predict(passenger_data)[0])

    return {
        "predicted_survived": prediction,
        "prediction_label": (
            "Survived" if prediction == 1
            else "Did Not Survive"
        )
    }

